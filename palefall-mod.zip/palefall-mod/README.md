# The Pale Fall — Fabric mod (Minecraft 1.21.1)

Zombie apocalypse with a story. Chapter 1 content:

- **Zombies**: Walker, Runner, Heavy (armoured), Screamer (calls the horde). They do not burn in daylight.
- **Night hordes** around every survival player; every 5th night is a **Blood Moon**.
- **Pistol** (hitscan, headshots, gunfire attracts zombies) + **Pistol Ammo**.
- **Barricade** block for boarding up windows/doors (axe to break).
- **Journal pages 1-6**, quests, and **Ranger Kit** (survivor NPC).
- **Structures**: Boarded House, Police Station, Survivor Bunker (worldgen).
- Thai + English (`th_th`, `en_us`).

## Build
1. Install JDK 21. Open this folder in IntelliJ IDEA (or run `gradle wrapper` once, then `./gradlew build`).
2. `./gradlew runClient` to test, `./gradlew build` -> `build/libs/palefall-0.1.0.jar`.
3. Put the jar + Fabric API in `mods/`.

## Commands
- `/palefall quest` — show objective
- `/palefall stage <0-5>` (op) — jump stage
- `/palefall horde [size]` (op) — spawn a horde now

## Regenerate resources
`python3 tools/generate_resources.py` (needs Pillow), then `python3 tools/validate.py`.
