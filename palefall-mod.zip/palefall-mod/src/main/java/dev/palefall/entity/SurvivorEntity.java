package dev.palefall.entity;

import dev.palefall.story.Quests;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/** Ranger Kit - the friendly survivor who lives in the bunker and drives the story forward. */
public class SurvivorEntity extends PathAwareEntity {
	public SurvivorEntity(EntityType<? extends PathAwareEntity> type, World world) {
		super(type, world);
		setInvulnerable(true);
		setPersistent();
	}

	public static DefaultAttributeContainer.Builder attributes() {
		return MobEntity.createMobAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 40.0)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25);
	}

	@Override
	protected void initGoals() {
		goalSelector.add(0, new SwimGoal(this));
		goalSelector.add(1, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
		goalSelector.add(2, new LookAroundGoal(this));
	}

	@Override
	public boolean canImmediatelyDespawn(double distanceSquared) {
		return false;
	}

	@Override
	public ActionResult interactMob(PlayerEntity player, Hand hand) {
		if (hand != Hand.MAIN_HAND) {
			return ActionResult.PASS;
		}
		if (!getWorld().isClient && player instanceof ServerPlayerEntity serverPlayer) {
			Quests.talkToKit(serverPlayer);
		}
		return ActionResult.SUCCESS;
	}
}
