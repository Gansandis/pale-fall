package dev.palefall.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

/** The four infected variants of The Pale Fall. They do not burn in daylight. */
public final class PaleZombies {
	private PaleZombies() {}

	/** Slow, steady, always in numbers. */
	public static class Walker extends ZombieEntity {
		public Walker(EntityType<? extends ZombieEntity> type, World world) {
			super(type, world);
		}

		public static DefaultAttributeContainer.Builder attributes() {
			return ZombieEntity.createZombieAttributes()
					.add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
					.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.18)
					.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 3.0);
		}

		@Override
		protected boolean burnsInDaylight() {
			return false;
		}
	}

	/** Fast and fragile - shoot it first. */
	public static class Runner extends ZombieEntity {
		public Runner(EntityType<? extends ZombieEntity> type, World world) {
			super(type, world);
		}

		public static DefaultAttributeContainer.Builder attributes() {
			return ZombieEntity.createZombieAttributes()
					.add(EntityAttributes.GENERIC_MAX_HEALTH, 14.0)
					.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.31)
					.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 2.0);
		}

		@Override
		protected boolean burnsInDaylight() {
			return false;
		}
	}

	/** Armoured brute: lots of health, hits hard, barely flinches. */
	public static class Heavy extends ZombieEntity {
		public Heavy(EntityType<? extends ZombieEntity> type, World world) {
			super(type, world);
			equipStack(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
			equipStack(EquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE));
			setEquipmentDropChance(EquipmentSlot.HEAD, 0.05f);
			setEquipmentDropChance(EquipmentSlot.CHEST, 0.05f);
		}

		public static DefaultAttributeContainer.Builder attributes() {
			return ZombieEntity.createZombieAttributes()
					.add(EntityAttributes.GENERIC_MAX_HEALTH, 50.0)
					.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.16)
					.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 6.0)
					.add(EntityAttributes.GENERIC_ARMOR, 6.0)
					.add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.7);
		}

		@Override
		protected boolean burnsInDaylight() {
			return false;
		}
	}

	/** Roars when it spots a target and drags every zombie within 24 blocks onto that target. */
	public static class Screamer extends ZombieEntity {
		private int screamCooldown = 40;

		public Screamer(EntityType<? extends ZombieEntity> type, World world) {
			super(type, world);
		}

		public static DefaultAttributeContainer.Builder attributes() {
			return ZombieEntity.createZombieAttributes()
					.add(EntityAttributes.GENERIC_MAX_HEALTH, 16.0)
					.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.22)
					.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 2.0);
		}

		@Override
		protected boolean burnsInDaylight() {
			return false;
		}

		@Override
		public void tickMovement() {
			super.tickMovement();
			if (getWorld().isClient || !isAlive()) {
				return;
			}
			LivingEntity target = getTarget();
			if (target != null && --screamCooldown <= 0) {
				screamCooldown = 160;
				scream(target);
			}
		}

		private void scream(LivingEntity target) {
			getWorld().playSound(null, getBlockPos(), SoundEvents.ENTITY_RAVAGER_ROAR,
					SoundCategory.HOSTILE, 2.0f, 1.5f);
			for (ZombieEntity other : getWorld().getEntitiesByClass(ZombieEntity.class,
					getBoundingBox().expand(24.0), z -> z != this && z.isAlive())) {
				other.setTarget(target);
			}
		}
	}
}
