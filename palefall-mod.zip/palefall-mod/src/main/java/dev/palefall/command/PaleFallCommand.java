package dev.palefall.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import dev.palefall.story.Quests;
import dev.palefall.world.HordeSpawner;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

/**
 * /palefall quest          - show the current objective
 * /palefall stage <0-5>    - (op) jump to a story stage
 * /palefall horde [size]   - (op) spawn a horde near you right now
 */
public final class PaleFallCommand {
	private PaleFallCommand() {}

	public static void init() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(CommandManager.literal("palefall")
						.then(CommandManager.literal("quest").executes(ctx -> {
							ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
							Quests.showObjective(player);
							return 1;
						}))
						.then(CommandManager.literal("stage")
								.requires(src -> src.hasPermissionLevel(2))
								.then(CommandManager.argument("n", IntegerArgumentType.integer(0, Quests.MAX_STAGE))
										.executes(ctx -> {
											ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
											Quests.setStage(player, IntegerArgumentType.getInteger(ctx, "n"));
											return 1;
										})))
						.then(CommandManager.literal("horde")
								.requires(src -> src.hasPermissionLevel(2))
								.executes(ctx -> horde(ctx.getSource().getPlayerOrThrow(), 6))
								.then(CommandManager.argument("size", IntegerArgumentType.integer(1, 30))
										.executes(ctx -> horde(ctx.getSource().getPlayerOrThrow(),
												IntegerArgumentType.getInteger(ctx, "size")))))));
	}

	private static int horde(ServerPlayerEntity player, int size) {
		int spawned = HordeSpawner.spawnGroup((ServerWorld) player.getWorld(), player, size, true);
		player.sendMessage(Text.translatable("message.palefall.horde_spawned", spawned));
		return spawned;
	}
}
