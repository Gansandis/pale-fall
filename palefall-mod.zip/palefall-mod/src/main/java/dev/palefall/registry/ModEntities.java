package dev.palefall.registry;

import dev.palefall.PaleFall;
import dev.palefall.entity.PaleZombies;
import dev.palefall.entity.SurvivorEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModEntities {
	private ModEntities() {}

	public static final EntityType<PaleZombies.Walker> WALKER = register("walker_zombie",
			EntityType.Builder.<PaleZombies.Walker>create(PaleZombies.Walker::new, SpawnGroup.MONSTER)
					.dimensions(0.6f, 1.95f).maxTrackingRange(8));

	public static final EntityType<PaleZombies.Runner> RUNNER = register("runner_zombie",
			EntityType.Builder.<PaleZombies.Runner>create(PaleZombies.Runner::new, SpawnGroup.MONSTER)
					.dimensions(0.6f, 1.95f).maxTrackingRange(8));

	public static final EntityType<PaleZombies.Heavy> HEAVY = register("heavy_zombie",
			EntityType.Builder.<PaleZombies.Heavy>create(PaleZombies.Heavy::new, SpawnGroup.MONSTER)
					.dimensions(0.72f, 2.25f).maxTrackingRange(8));

	public static final EntityType<PaleZombies.Screamer> SCREAMER = register("screamer_zombie",
			EntityType.Builder.<PaleZombies.Screamer>create(PaleZombies.Screamer::new, SpawnGroup.MONSTER)
					.dimensions(0.6f, 1.95f).maxTrackingRange(8));

	public static final EntityType<SurvivorEntity> SURVIVOR = register("survivor",
			EntityType.Builder.<SurvivorEntity>create(SurvivorEntity::new, SpawnGroup.CREATURE)
					.dimensions(0.6f, 1.95f).maxTrackingRange(10));

	private static <T extends Entity> EntityType<T> register(String name, EntityType.Builder<T> builder) {
		return Registry.register(Registries.ENTITY_TYPE, PaleFall.id(name), builder.build(name));
	}

	public static void init() {
		FabricDefaultAttributeRegistry.register(WALKER, PaleZombies.Walker.attributes());
		FabricDefaultAttributeRegistry.register(RUNNER, PaleZombies.Runner.attributes());
		FabricDefaultAttributeRegistry.register(HEAVY, PaleZombies.Heavy.attributes());
		FabricDefaultAttributeRegistry.register(SCREAMER, PaleZombies.Screamer.attributes());
		FabricDefaultAttributeRegistry.register(SURVIVOR, SurvivorEntity.attributes());
	}
}
