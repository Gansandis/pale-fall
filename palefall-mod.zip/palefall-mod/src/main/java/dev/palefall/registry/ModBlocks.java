package dev.palefall.registry;

import dev.palefall.PaleFall;
import dev.palefall.block.BarricadeBlock;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.block.enums.NoteBlockInstrument;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;

public final class ModBlocks {
	private ModBlocks() {}

	public static final Block BARRICADE = Registry.register(Registries.BLOCK, PaleFall.id("barricade"),
			new BarricadeBlock(AbstractBlock.Settings.create()
					.mapColor(MapColor.OAK_TAN)
					.instrument(NoteBlockInstrument.BASS)
					.strength(2.0f, 3.0f)
					.sounds(BlockSoundGroup.WOOD)
					.nonOpaque()
					.burnable()));

	/** Forces class loading so static registration runs during mod init. */
	public static void init() {}
}
