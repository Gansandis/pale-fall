package dev.palefall.registry;

import dev.palefall.PaleFall;
import dev.palefall.item.JournalPageItem;
import dev.palefall.item.PistolItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public final class ModItems {
	private ModItems() {}

	public static final int JOURNAL_PAGE_COUNT = 6;

	public static final Item PISTOL = register("pistol", new PistolItem(new Item.Settings().maxCount(1)));
	public static final Item PISTOL_AMMO = register("pistol_ammo", new Item(new Item.Settings()));
	public static final Item BARRICADE = register("barricade", new BlockItem(ModBlocks.BARRICADE, new Item.Settings()));

	public static final Item[] JOURNAL_PAGES = new Item[JOURNAL_PAGE_COUNT];

	static {
		for (int i = 0; i < JOURNAL_PAGE_COUNT; i++) {
			JOURNAL_PAGES[i] = register("journal_page_" + (i + 1),
					new JournalPageItem(new Item.Settings().maxCount(1), i + 1));
		}
	}

	public static final Item WALKER_EGG = register("walker_zombie_spawn_egg",
			new SpawnEggItem(ModEntities.WALKER, 0x6B8F5A, 0x3E3226, new Item.Settings()));
	public static final Item RUNNER_EGG = register("runner_zombie_spawn_egg",
			new SpawnEggItem(ModEntities.RUNNER, 0x8A7A55, 0x5C2B2B, new Item.Settings()));
	public static final Item HEAVY_EGG = register("heavy_zombie_spawn_egg",
			new SpawnEggItem(ModEntities.HEAVY, 0x55606B, 0x2B2B2B, new Item.Settings()));
	public static final Item SCREAMER_EGG = register("screamer_zombie_spawn_egg",
			new SpawnEggItem(ModEntities.SCREAMER, 0xC9D6C0, 0x7A1F1F, new Item.Settings()));
	public static final Item SURVIVOR_EGG = register("survivor_spawn_egg",
			new SpawnEggItem(ModEntities.SURVIVOR, 0x7A5A3A, 0x2F4F2F, new Item.Settings()));

	public static final ItemGroup GROUP = Registry.register(Registries.ITEM_GROUP, PaleFall.id("main"),
			FabricItemGroup.builder()
					.icon(() -> new ItemStack(PISTOL))
					.displayName(Text.translatable("itemGroup.palefall.main"))
					.entries((context, entries) -> {
						entries.add(PISTOL);
						entries.add(PISTOL_AMMO);
						entries.add(BARRICADE);
						for (Item page : JOURNAL_PAGES) {
							entries.add(page);
						}
						entries.add(WALKER_EGG);
						entries.add(RUNNER_EGG);
						entries.add(HEAVY_EGG);
						entries.add(SCREAMER_EGG);
						entries.add(SURVIVOR_EGG);
					})
					.build());

	private static Item register(String name, Item item) {
		return Registry.register(Registries.ITEM, PaleFall.id(name), item);
	}

	public static void init() {}
}
