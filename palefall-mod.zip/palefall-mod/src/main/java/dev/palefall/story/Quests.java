package dev.palefall.story;

import dev.palefall.registry.ModItems;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Story / quest logic.
 *
 * Stages:
 *  0  read Dr. Mara's note (journal page 1)
 *  1  get a pistol
 *  2  kill 10 zombies
 *  3  read 4 journal pages in total
 *  4  report to Ranger Kit at the bunker
 *  5  chapter 1 finished (teaser for the lab)
 */
public final class Quests {
	private Quests() {}

	public static final int STAGE_READ_NOTE = 0;
	public static final int STAGE_ARM = 1;
	public static final int STAGE_KILL = 2;
	public static final int STAGE_PAGES = 3;
	public static final int STAGE_REPORT = 4;
	public static final int STAGE_DONE = 5;
	public static final int MAX_STAGE = STAGE_DONE;

	public static final int KILLS_NEEDED = 10;
	public static final int PAGES_NEEDED = 4;

	public static PaleFallState.Data data(ServerPlayerEntity player) {
		return PaleFallState.get(player.getServer()).get(player.getUuid());
	}

	// ---------------------------------------------------------------- events

	public static void onJoin(ServerPlayerEntity player) {
		PaleFallState.Data d = data(player);
		if (!d.starterGiven) {
			d.starterGiven = true;
			player.giveItemStack(new ItemStack(ModItems.JOURNAL_PAGES[0]));
			player.sendMessage(Text.translatable("message.palefall.welcome").formatted(Formatting.GRAY, Formatting.ITALIC));
			player.sendMessage(Text.translatable("message.palefall.welcome_hint").formatted(Formatting.YELLOW));
		}
	}

	public static void onZombieKilled(ServerPlayerEntity player) {
		PaleFallState.Data d = data(player);
		d.kills++;
		if (d.stage == STAGE_KILL) {
			if (d.kills >= KILLS_NEEDED) {
				setStage(player, STAGE_PAGES);
			} else if (d.kills % 3 == 0) {
				player.sendMessage(objective(player, d), true);
			}
		}
	}

	/** Called periodically (every second) for each player. */
	public static void tickPlayer(ServerPlayerEntity player) {
		PaleFallState.Data d = data(player);
		if (d.stage == STAGE_ARM && hasPistol(player)) {
			setStage(player, STAGE_KILL);
		}
	}

	public static void readPage(ServerPlayerEntity player, int page) {
		PaleFallState.Data d = data(player);
		boolean firstRead = (d.pagesMask & (1 << (page - 1))) == 0;
		d.pagesMask |= 1 << (page - 1);

		player.sendMessage(Text.literal("── ").formatted(Formatting.DARK_GRAY)
				.append(Text.translatable("journal.palefall." + page + ".title").formatted(Formatting.GOLD, Formatting.BOLD))
				.append(Text.literal(" ──").formatted(Formatting.DARK_GRAY)));
		player.sendMessage(Text.translatable("journal.palefall." + page + ".body").formatted(Formatting.WHITE));
		player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ITEM_BOOK_PAGE_TURN,
				SoundCategory.PLAYERS, 1.0f, 1.0f);

		if (page == 1 && d.stage == STAGE_READ_NOTE) {
			setStage(player, STAGE_ARM);
		} else if (firstRead && d.stage == STAGE_PAGES) {
			if (pagesRead(d) >= PAGES_NEEDED) {
				setStage(player, STAGE_REPORT);
			} else {
				player.sendMessage(objective(player, d), true);
			}
		}
	}

	public static void talkToKit(ServerPlayerEntity player) {
		PaleFallState.Data d = data(player);
		Text name = Text.translatable("npc.palefall.kit").formatted(Formatting.GREEN);

		if (!d.gifted) {
			d.gifted = true;
			player.giveItemStack(new ItemStack(ModItems.PISTOL_AMMO, 8));
			player.sendMessage(Text.translatable("message.palefall.kit_gift").formatted(Formatting.GRAY, Formatting.ITALIC));
		}

		player.sendMessage(Text.empty().append(name).append(Text.literal(": ").formatted(Formatting.GRAY))
				.append(Text.translatable("dialogue.palefall.kit." + d.stage).formatted(Formatting.WHITE)));

		if (d.stage == STAGE_REPORT) {
			player.giveItemStack(new ItemStack(ModItems.JOURNAL_PAGES[5]));
			player.giveItemStack(new ItemStack(ModItems.PISTOL_AMMO, 8));
			setStage(player, STAGE_DONE);
		}
	}

	// ---------------------------------------------------------------- helpers

	public static void setStage(ServerPlayerEntity player, int stage) {
		PaleFallState.Data d = data(player);
		d.stage = Math.max(0, Math.min(MAX_STAGE, stage));
		player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP,
				SoundCategory.PLAYERS, 0.8f, 1.2f);
		player.sendMessage(Text.translatable("message.palefall.quest_update").formatted(Formatting.YELLOW, Formatting.BOLD));
		player.sendMessage(objective(player, d));
	}

	public static void showObjective(ServerPlayerEntity player) {
		PaleFallState.Data d = data(player);
		player.sendMessage(Text.translatable("message.palefall.quest_header").formatted(Formatting.GOLD, Formatting.BOLD));
		player.sendMessage(objective(player, d));
	}

	public static MutableText objective(ServerPlayerEntity player, PaleFallState.Data d) {
		return Text.translatable("quest.palefall.stage." + d.stage, d.kills, KILLS_NEEDED, pagesRead(d), PAGES_NEEDED)
				.formatted(Formatting.AQUA);
	}

	public static int pagesRead(PaleFallState.Data d) {
		return Integer.bitCount(d.pagesMask & 0b11111);
	}

	private static boolean hasPistol(ServerPlayerEntity player) {
		for (int i = 0; i < player.getInventory().size(); i++) {
			if (player.getInventory().getStack(i).isOf(ModItems.PISTOL)) {
				return true;
			}
		}
		return false;
	}
}
