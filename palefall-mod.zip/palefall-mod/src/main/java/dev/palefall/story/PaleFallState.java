package dev.palefall.story;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateManager;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Per-player story progress, saved with the world (overworld data folder). */
public class PaleFallState extends PersistentState {
	public static class Data {
		public int stage = 0;
		public int kills = 0;
		/** bit (n-1) set = journal page n has been read */
		public int pagesMask = 0;
		public boolean starterGiven = false;
		public boolean gifted = false;
	}

	private final Map<UUID, Data> players = new HashMap<>();

	public Data get(UUID id) {
		return players.computeIfAbsent(id, k -> new Data());
	}

	@Override
	public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
		NbtList list = new NbtList();
		for (Map.Entry<UUID, Data> e : players.entrySet()) {
			NbtCompound tag = new NbtCompound();
			tag.putUuid("id", e.getKey());
			tag.putInt("stage", e.getValue().stage);
			tag.putInt("kills", e.getValue().kills);
			tag.putInt("pages", e.getValue().pagesMask);
			tag.putBoolean("starter", e.getValue().starterGiven);
			tag.putBoolean("gifted", e.getValue().gifted);
			list.add(tag);
		}
		nbt.put("players", list);
		return nbt;
	}

	public static PaleFallState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
		PaleFallState state = new PaleFallState();
		NbtList list = nbt.getList("players", NbtElement.COMPOUND_TYPE);
		for (int i = 0; i < list.size(); i++) {
			NbtCompound tag = list.getCompound(i);
			Data d = new Data();
			d.stage = tag.getInt("stage");
			d.kills = tag.getInt("kills");
			d.pagesMask = tag.getInt("pages");
			d.starterGiven = tag.getBoolean("starter");
			d.gifted = tag.getBoolean("gifted");
			state.players.put(tag.getUuid("id"), d);
		}
		return state;
	}

	private static final Type<PaleFallState> TYPE = new Type<>(PaleFallState::new, PaleFallState::fromNbt, null);

	/** Always marks dirty, since callers fetch this to mutate it. */
	public static PaleFallState get(MinecraftServer server) {
		PersistentStateManager manager = server.getOverworld().getPersistentStateManager();
		PaleFallState state = manager.getOrCreate(TYPE, "palefall_story");
		state.markDirty();
		return state;
	}
}
