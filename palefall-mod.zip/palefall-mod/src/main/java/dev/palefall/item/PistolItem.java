package dev.palefall.item;

import dev.palefall.registry.ModItems;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.List;

/**
 * Hitscan pistol. Right-click to fire. Uses one Pistol Ammo per shot. Headshots deal extra damage.
 * Gunfire is loud: nearby idle zombies walk towards the shooter.
 */
public class PistolItem extends Item {
	private static final double RANGE = 48.0;
	private static final float DAMAGE = 7.0f;
	private static final float HEADSHOT_DAMAGE = 14.0f;
	private static final int COOLDOWN_TICKS = 14;
	private static final double NOISE_RADIUS = 22.0;

	public PistolItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);
		if (player.getItemCooldownManager().isCoolingDown(this)) {
			return TypedActionResult.fail(stack);
		}

		int ammoSlot = player.isCreative() ? -1 : findAmmo(player);
		if (!player.isCreative() && ammoSlot < 0) {
			if (!world.isClient) {
				world.playSound(null, player.getBlockPos(), SoundEvents.BLOCK_DISPENSER_FAIL,
						SoundCategory.PLAYERS, 1.0f, 1.6f);
				player.sendMessage(Text.translatable("message.palefall.no_ammo").formatted(Formatting.RED), true);
			}
			return TypedActionResult.fail(stack);
		}

		if (!world.isClient && world instanceof ServerWorld serverWorld) {
			if (ammoSlot >= 0) {
				player.getInventory().getStack(ammoSlot).decrement(1);
			}
			fire(serverWorld, player);
		}
		player.getItemCooldownManager().set(this, COOLDOWN_TICKS);
		return TypedActionResult.success(stack, world.isClient());
	}

	private static int findAmmo(PlayerEntity player) {
		for (int i = 0; i < player.getInventory().size(); i++) {
			if (player.getInventory().getStack(i).isOf(ModItems.PISTOL_AMMO)) {
				return i;
			}
		}
		return -1;
	}

	private void fire(ServerWorld world, PlayerEntity player) {
		Vec3d start = player.getEyePos();
		Vec3d look = player.getRotationVec(1.0f);
		Vec3d end = start.add(look.multiply(RANGE));

		BlockHitResult blockHit = world.raycast(new RaycastContext(start, end,
				RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
		if (blockHit.getType() != HitResult.Type.MISS) {
			end = blockHit.getPos();
		}

		Box searchBox = player.getBoundingBox().stretch(look.multiply(RANGE)).expand(1.0);
		EntityHitResult entityHit = ProjectileUtil.raycast(player, start, end, searchBox,
				e -> !e.isSpectator() && e.canHit(), start.squaredDistanceTo(end));
		if (entityHit != null) {
			end = entityHit.getPos();
		}

		world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST,
				SoundCategory.PLAYERS, 1.6f, 0.8f);

		// muzzle smoke + tracer
		Vec3d muzzle = start.add(look.multiply(0.8));
		world.spawnParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y - 0.15, muzzle.z, 4, 0.03, 0.03, 0.03, 0.01);
		double length = start.distanceTo(end);
		for (double d = 1.5; d < length; d += 1.0) {
			Vec3d p = start.add(look.multiply(d));
			world.spawnParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 1, 0, 0, 0, 0);
		}

		if (entityHit != null && entityHit.getEntity() instanceof LivingEntity target) {
			boolean headshot = entityHit.getPos().y >= target.getEyeY() - 0.2;
			target.damage(world.getDamageSources().playerAttack(player), headshot ? HEADSHOT_DAMAGE : DAMAGE);
			target.takeKnockback(0.4, -look.x, -look.z);
			if (headshot) {
				player.sendMessage(Text.translatable("message.palefall.headshot").formatted(Formatting.GOLD), true);
			}
		}

		// gunfire is loud
		for (ZombieEntity zombie : world.getEntitiesByClass(ZombieEntity.class,
				player.getBoundingBox().expand(NOISE_RADIUS), z -> z.isAlive() && z.getTarget() == null)) {
			zombie.getNavigation().startMovingTo(player.getX(), player.getY(), player.getZ(), 1.0);
		}
	}

	@Override
	public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
		tooltip.add(Text.translatable("tooltip.palefall.pistol").formatted(Formatting.GRAY));
		tooltip.add(Text.translatable("tooltip.palefall.pistol_noise").formatted(Formatting.DARK_RED));
	}
}
