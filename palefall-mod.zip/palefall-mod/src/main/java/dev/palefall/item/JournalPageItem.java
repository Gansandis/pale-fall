package dev.palefall.item;

import dev.palefall.story.Quests;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/** A torn journal page. Right-click to read it; the text appears in chat and counts for the quest. */
public class JournalPageItem extends Item {
	private final int page;

	public JournalPageItem(Settings settings, int page) {
		super(settings);
		this.page = page;
	}

	public int getPage() {
		return page;
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);
		if (!world.isClient && player instanceof ServerPlayerEntity serverPlayer) {
			Quests.readPage(serverPlayer, page);
		}
		return TypedActionResult.success(stack, world.isClient());
	}

	@Override
	public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
		tooltip.add(Text.translatable("tooltip.palefall.journal_page", page).formatted(Formatting.GRAY));
	}
}
