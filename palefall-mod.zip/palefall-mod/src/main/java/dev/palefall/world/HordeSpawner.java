package dev.palefall.world;

import dev.palefall.registry.ModEntities;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Difficulty;
import net.minecraft.world.GameRules;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

/**
 * Night-time hordes and ambience. Every ~30 seconds of night a group of infected spawns
 * 26-42 blocks away from each survival-mode player and heads for them. Group size grows with the day count.
 */
public final class HordeSpawner {
	private HordeSpawner() {}

	// "hard" tuning: a new group every 20 s (10 s on a Blood Moon)
	private static final int HORDE_INTERVAL_TICKS = 400;
	private static final int BLOOD_MOON_INTERVAL_TICKS = 200;
	private static final int AMBIENT_INTERVAL_TICKS = 120;
	private static final int MAX_ZOMBIES_NEAR_PLAYER = 36;
	private static final int MAX_ZOMBIES_BLOOD_MOON = 56;

	public static void init() {
		ServerTickEvents.END_WORLD_TICK.register(HordeSpawner::tick);
	}

	public static boolean isNight(ServerWorld world) {
		long t = world.getTimeOfDay() % 24000L;
		return t >= 13000L && t < 23000L;
	}

	/** Every 5th night (day 4, 9, 14 ...) the moon turns red: bigger groups, spawned twice as often. */
	public static boolean isBloodMoon(ServerWorld world) {
		return world.getTimeOfDay() / 24000L % 5L == 4L;
	}

	private static void tick(ServerWorld world) {
		if (world.getRegistryKey() != World.OVERWORLD) {
			return;
		}
		long time = world.getTime();

		if (time % 20 == 0) {
			for (ServerPlayerEntity player : world.getPlayers()) {
				dev.palefall.story.Quests.tickPlayer(player);
			}
		}

		if (!isNight(world)) {
			return;
		}

		boolean bloodMoon = isBloodMoon(world);

		// warn players at dusk
		if (bloodMoon && world.getTimeOfDay() % 24000L == 13000L) {
			for (ServerPlayerEntity player : world.getPlayers()) {
				player.sendMessage(Text.translatable("message.palefall.blood_moon")
						.formatted(Formatting.DARK_RED, Formatting.BOLD));
			}
		}

		if (time % AMBIENT_INTERVAL_TICKS == 0) {
			ambient(world);
		}

		int interval = bloodMoon ? BLOOD_MOON_INTERVAL_TICKS : HORDE_INTERVAL_TICKS;
		if (time % interval == 0
				&& world.getDifficulty() != Difficulty.PEACEFUL
				&& world.getGameRules().getBoolean(GameRules.DO_MOB_SPAWNING)) {
			for (ServerPlayerEntity player : world.getPlayers()) {
				if (player.isCreative() || player.isSpectator()) {
					continue;
				}
				long day = world.getTimeOfDay() / 24000L;
				int size = 3 + (int) Math.min(day, 6) + world.random.nextInt(4);
				if (bloodMoon) {
					size *= 2;
				}
				spawnGroup(world, player, size, false);
			}
		}
	}

	private static void ambient(ServerWorld world) {
		Random r = world.random;
		for (ServerPlayerEntity player : world.getPlayers()) {
			if (r.nextFloat() > 0.35f) {
				continue;
			}
			double ang = r.nextDouble() * Math.PI * 2;
			double dist = 28 + r.nextDouble() * 16;
			double x = player.getX() + Math.cos(ang) * dist;
			double z = player.getZ() + Math.sin(ang) * dist;
			world.playSound(null, x, player.getY(), z, SoundEvents.ENTITY_ZOMBIE_AMBIENT,
					SoundCategory.AMBIENT, 1.6f, 0.55f + r.nextFloat() * 0.2f);
			if (r.nextFloat() < 0.15f) {
				player.sendMessage(Text.translatable("message.palefall.distant_horde")
						.formatted(Formatting.DARK_GRAY, Formatting.ITALIC), true);
			}
		}
	}

	/** Spawns a mixed group near the player. Returns how many zombies were created. */
	public static int spawnGroup(ServerWorld world, ServerPlayerEntity player, int size, boolean ignoreCap) {
		if (!ignoreCap) {
			int near = world.getEntitiesByClass(ZombieEntity.class,
					player.getBoundingBox().expand(64.0), z -> true).size();
			int cap = isBloodMoon(world) ? MAX_ZOMBIES_BLOOD_MOON : MAX_ZOMBIES_NEAR_PLAYER;
			if (near >= cap) {
				return 0;
			}
		}

		Random r = world.random;
		BlockPos center = null;
		for (int attempt = 0; attempt < 10 && center == null; attempt++) {
			double ang = r.nextDouble() * Math.PI * 2;
			double dist = 26 + r.nextDouble() * 16;
			BlockPos candidate = surface(world,
					MathHelper.floor(player.getX() + Math.cos(ang) * dist),
					MathHelper.floor(player.getZ() + Math.sin(ang) * dist));
			if (isValid(world, candidate)) {
				center = candidate;
			}
		}
		if (center == null) {
			return 0;
		}

		int spawned = 0;
		for (int i = 0; i < size; i++) {
			BlockPos pos = surface(world, center.getX() + r.nextInt(7) - 3, center.getZ() + r.nextInt(7) - 3);
			if (!isValid(world, pos)) {
				continue;
			}
			ZombieEntity zombie = pickType(r).spawn(world, pos, SpawnReason.EVENT);
			if (zombie != null) {
				zombie.setTarget(player);
				spawned++;
			}
		}
		return spawned;
	}

	private static BlockPos surface(ServerWorld world, int x, int z) {
		return new BlockPos(x, world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z), z);
	}

	private static boolean isValid(ServerWorld world, BlockPos pos) {
		BlockPos below = pos.down();
		return world.getFluidState(below).isEmpty()
				&& world.getFluidState(pos).isEmpty()
				&& world.getBlockState(below).isSideSolidFullSquare(world, below, Direction.UP);
	}

	private static EntityType<? extends ZombieEntity> pickType(Random r) {
		float roll = r.nextFloat();
		if (roll < 0.45f) {
			return ModEntities.WALKER;
		} else if (roll < 0.75f) {
			return ModEntities.RUNNER;
		} else if (roll < 0.90f) {
			return ModEntities.HEAVY;
		}
		return ModEntities.SCREAMER;
	}
}
