package dev.palefall;

import dev.palefall.command.PaleFallCommand;
import dev.palefall.registry.ModBlocks;
import dev.palefall.registry.ModEntities;
import dev.palefall.registry.ModItems;
import dev.palefall.story.Quests;
import dev.palefall.world.HordeSpawner;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PaleFall implements ModInitializer {
	public static final String MOD_ID = "palefall";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static Identifier id(String path) {
		return Identifier.of(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModBlocks.init();
		ModEntities.init();
		ModItems.init();

		HordeSpawner.init();
		PaleFallCommand.init();

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> Quests.onJoin(handler.getPlayer()));

		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (entity instanceof ZombieEntity && source.getAttacker() instanceof ServerPlayerEntity player) {
				Quests.onZombieKilled(player);
			}
		});

		LOGGER.info("The Pale Fall has begun.");
	}
}
