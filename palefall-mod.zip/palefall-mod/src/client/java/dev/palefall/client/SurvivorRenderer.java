package dev.palefall.client;

import dev.palefall.entity.SurvivorEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.VillagerResemblingModel;
import net.minecraft.util.Identifier;

/** Ranger Kit uses the villager body with the plain villager skin. */
public class SurvivorRenderer extends MobEntityRenderer<SurvivorEntity, VillagerResemblingModel<SurvivorEntity>> {
	private static final Identifier TEXTURE = Identifier.ofVanilla("textures/entity/villager/villager.png");

	public SurvivorRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new VillagerResemblingModel<>(ctx.getPart(EntityModelLayers.VILLAGER)), 0.5f);
	}

	@Override
	public Identifier getTexture(SurvivorEntity entity) {
		return TEXTURE;
	}
}
