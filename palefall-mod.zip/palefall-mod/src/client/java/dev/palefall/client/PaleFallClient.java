package dev.palefall.client;

import dev.palefall.PaleFall;
import dev.palefall.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;

public class PaleFallClient implements ClientModInitializer {
	private static Identifier skin(String name) {
		return PaleFall.id("textures/entity/" + name + ".png");
	}

	@Override
	public void onInitializeClient() {
		// explicit type witness: all variants share the ZombieEntity renderer type
		EntityRendererRegistry.<ZombieEntity>register(ModEntities.WALKER,
				ctx -> new PaleZombieRenderer(ctx, skin("walker"), 1.0f));
		EntityRendererRegistry.<ZombieEntity>register(ModEntities.RUNNER,
				ctx -> new PaleZombieRenderer(ctx, skin("runner"), 0.95f));
		EntityRendererRegistry.<ZombieEntity>register(ModEntities.HEAVY,
				ctx -> new PaleZombieRenderer(ctx, skin("heavy"), 1.15f));
		EntityRendererRegistry.<ZombieEntity>register(ModEntities.SCREAMER,
				ctx -> new PaleZombieRenderer(ctx, skin("screamer"), 1.0f));

		EntityRendererRegistry.register(ModEntities.SURVIVOR, SurvivorRenderer::new);
	}
}
