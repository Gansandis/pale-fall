package dev.palefall.client;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.ZombieEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;

/** Re-uses the vanilla zombie model with a different skin and size per variant. */
public class PaleZombieRenderer extends ZombieEntityRenderer {
	private final Identifier texture;
	private final float scale;

	public PaleZombieRenderer(EntityRendererFactory.Context ctx, Identifier texture, float scale) {
		super(ctx);
		this.texture = texture;
		this.scale = scale;
	}

	@Override
	public Identifier getTexture(ZombieEntity entity) {
		return texture;
	}

	@Override
	protected void scale(ZombieEntity entity, MatrixStack matrices, float amount) {
		super.scale(entity, matrices, amount);
		matrices.scale(scale, scale, scale);
	}
}
