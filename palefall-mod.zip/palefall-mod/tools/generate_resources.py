#!/usr/bin/env python3
"""
Generates every non-Java resource of the mod into src/main/resources:
textures, models, blockstates, lang (en_us + th_th), loot tables, recipes, tags,
worldgen JSON and the structure .nbt files.

Run:  python3 tools/generate_resources.py
"""
import gzip
import json
import os
import random
import struct

from PIL import Image, ImageDraw

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources")
ROOT = os.path.abspath(ROOT)
MOD = "palefall"
ASSETS = os.path.join(ROOT, "assets", MOD)
DATA = os.path.join(ROOT, "data", MOD)

DATA_VERSION = 3955  # Minecraft 1.21.1


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.write("\n")


# ====================================================================== textures
def make_textures():
    os.makedirs(os.path.join(ASSETS, "textures", "item"), exist_ok=True)
    os.makedirs(os.path.join(ASSETS, "textures", "block"), exist_ok=True)

    # --- pistol (16x16)
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    dark, mid, light, grip, grip_d = (38, 38, 42, 255), (70, 70, 78, 255), (120, 120, 130, 255), (96, 62, 36, 255), (66, 42, 24, 255)
    d.rectangle([2, 5, 13, 7], fill=mid)          # slide
    d.rectangle([2, 5, 13, 5], fill=light)        # highlight
    d.rectangle([2, 7, 13, 7], fill=dark)         # shadow
    d.rectangle([13, 6, 14, 6], fill=dark)        # muzzle
    d.rectangle([3, 8, 8, 8], fill=dark)          # frame
    d.rectangle([9, 8, 10, 9], fill=dark)         # trigger guard
    d.rectangle([4, 9, 7, 13], fill=grip)         # grip
    d.rectangle([4, 9, 4, 13], fill=grip_d)
    d.rectangle([5, 14, 7, 14], fill=dark)
    d.point([3, 4], fill=dark)                    # rear sight
    d.point([13, 4], fill=dark)                   # front sight
    img.save(os.path.join(ASSETS, "textures", "item", "pistol.png"))

    # --- ammo
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    brass, brass_d, tip = (214, 170, 52, 255), (150, 110, 30, 255), (184, 115, 51, 255)
    for x in (3, 7, 11):
        d.rectangle([x, 7, x + 2, 13], fill=brass)
        d.rectangle([x, 7, x, 13], fill=brass_d)
        d.rectangle([x, 4, x + 2, 6], fill=tip)
        d.point([x + 1, 3], fill=tip)
        d.rectangle([x, 13, x + 2, 13], fill=brass_d)
    img.save(os.path.join(ASSETS, "textures", "item", "pistol_ammo.png"))

    # --- journal page
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    paper, edge, ink, stain = (232, 220, 181, 255), (180, 160, 120, 255), (70, 55, 40, 255), (120, 40, 36, 255)
    d.rectangle([3, 1, 12, 14], fill=paper, outline=edge)
    d.point([12, 1], fill=(0, 0, 0, 0))   # torn corner
    d.point([12, 2], fill=(0, 0, 0, 0))
    d.point([11, 1], fill=(0, 0, 0, 0))
    for y in (4, 6, 8, 10):
        d.line([5, y, 10, y], fill=ink)
    d.line([5, 12, 8, 12], fill=ink)
    d.rectangle([9, 11, 11, 13], fill=stain)
    img.save(os.path.join(ASSETS, "textures", "item", "journal_page.png"))

    # --- barricade (block texture, 16x16 planks with nails)
    rng = random.Random(7)
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 255))
    px = img.load()
    base_cols = [(122, 92, 54), (134, 102, 60), (110, 82, 47), (128, 97, 57)]
    for row in range(4):
        col = base_cols[row]
        for y in range(row * 4, row * 4 + 4):
            for x in range(16):
                shade = rng.randint(-10, 10)
                c = tuple(max(0, min(255, v + shade)) for v in col)
                if y == row * 4 + 3:
                    c = tuple(int(v * 0.62) for v in c)   # gap between planks
                px[x, y] = c + (255,)
    for (nx, ny) in [(1, 1), (14, 1), (1, 5), (14, 5), (1, 9), (14, 9), (1, 13), (14, 13)]:
        px[nx, ny] = (60, 60, 66, 255)
    img.save(os.path.join(ASSETS, "textures", "block", "barricade.png"))

    # --- mod icon (128x128)
    img = Image.new("RGBA", (128, 128), (18, 24, 22, 255))
    d = ImageDraw.Draw(img)
    for i in range(128):                                  # vertical gradient
        g = int(18 + i * 0.18)
        d.line([0, i, 127, i], fill=(g, g + 8, g + 4, 255))
    d.ellipse([28, 20, 100, 92], fill=(207, 216, 200, 255))
    for (cx, cy, r) in [(50, 40, 6), (74, 56, 9), (58, 72, 5), (80, 36, 4)]:
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(160, 172, 156, 255))
    d.polygon([(0, 128), (0, 104), (22, 96), (40, 108), (62, 98), (90, 110), (110, 100), (128, 106), (128, 128)],
              fill=(8, 12, 10, 255))
    for x in (18, 46, 74, 100):                           # silhouettes
        d.rectangle([x, 92, x + 4, 108], fill=(8, 12, 10, 255))
        d.ellipse([x - 1, 86, x + 5, 93], fill=(8, 12, 10, 255))
    img.save(os.path.join(ASSETS, "icon.png"))


# ====================================================================== zombie skins (64x64, biped layout)
def _box(px, ox, oy, w, h, d, fn):
    """paint the six faces of a box using the standard skin UV layout; fn(face, u, v, w, h) -> rgba"""
    faces = {
        "top": (ox + d, oy, w, d), "bottom": (ox + d + w, oy, w, d),
        "right": (ox, oy + d, d, h), "front": (ox + d, oy + d, w, h),
        "left": (ox + d + w, oy + d, d, h), "back": (ox + 2 * d + w, oy + d, w, h),
    }
    for face, (fx, fy, fw, fh) in faces.items():
        for v in range(fh):
            for u in range(fw):
                px[fx + u, fy + v] = fn(face, u, v, fw, fh)


def _shade(c, amt):
    return tuple(max(0, min(255, int(x + amt))) for x in c[:3]) + (255,)


def make_skin(name, seed, skin, shirt, pants, blood, eyes, mouth_open=False, vest=False, gown=False):
    rng = random.Random(seed)
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    px = img.load()
    DARK = (20, 16, 16, 255)

    def noise(c, spread=9):
        return _shade(c, rng.randint(-spread, spread))

    def head(face, u, v, w, h):
        c = noise(skin)
        if face == "front":
            if v in (3, 4) and u in (1, 2, 5, 6):          # eyes
                c = eyes if v == 4 else DARK
            if v == 6 and 2 <= u <= 5:                      # mouth
                c = DARK
            if mouth_open and v in (6, 7) and 2 <= u <= 5:
                c = (60, 8, 8, 255)
            if rng.random() < 0.06:
                c = noise(blood, 6)
        elif face == "top" or face == "back":
            c = noise(_shade(skin, -35), 6)                 # matted hair
        return c

    def torso(face, u, v, w, h):
        base = shirt
        if vest and face in ("front", "back"):
            base = (38, 40, 46, 255)
            if u in (1, 6) or v in (4, 9):
                base = (22, 22, 26, 255)                    # straps
        if gown and face in ("front", "back") and v > 2:
            base = (150, 175, 195, 255)
        c = noise(base)
        if rng.random() < 0.07:
            c = noise(blood, 8)
        if face in ("front", "back") and rng.random() < 0.04:
            c = (0, 0, 0, 0) if False else noise(skin, 6)   # torn cloth shows skin
        return c

    def arm(face, u, v, w, h):
        if v < 4 and not gown:
            c = noise(shirt)                                # sleeve
        else:
            c = noise(skin)
        if rng.random() < 0.05:
            c = noise(blood, 8)
        return c

    def leg(face, u, v, w, h):
        c = noise(pants)
        if v > h - 3:
            c = noise(_shade(pants, -22), 5)                # worn shoes
        if rng.random() < 0.05:
            c = noise(blood, 8)
        return c

    _box(px, 0, 0, 8, 8, 8, head)
    _box(px, 16, 16, 8, 12, 4, torso)
    _box(px, 40, 16, 4, 12, 4, arm)
    _box(px, 0, 16, 4, 12, 4, leg)
    _box(px, 32, 48, 4, 12, 4, arm)
    _box(px, 16, 48, 4, 12, 4, leg)
    out = os.path.join(ASSETS, "textures", "entity")
    os.makedirs(out, exist_ok=True)
    img.save(os.path.join(out, f"{name}.png"))


def make_skins():
    # walker: rotten green skin, tattered blue shirt
    make_skin("walker", 11, skin=(111, 138, 92), shirt=(52, 82, 120), pants=(52, 48, 70),
              blood=(110, 24, 24), eyes=(20, 20, 20, 255))
    # runner: emaciated pale skin, torn grey hoodie, yellow eyes
    make_skin("runner", 22, skin=(186, 181, 154), shirt=(98, 100, 106), pants=(40, 44, 52),
              blood=(130, 28, 24), eyes=(240, 210, 40, 255))
    # heavy: grey-green skin, black riot vest, camo trousers
    make_skin("heavy", 33, skin=(112, 124, 108), shirt=(40, 42, 48), pants=(70, 82, 58),
              blood=(90, 20, 20), eyes=(210, 70, 40, 255), vest=True)
    # screamer: bluish pale skin, hospital gown, wide-open mouth, red eyes
    make_skin("screamer", 44, skin=(178, 196, 204), shirt=(150, 175, 195), pants=(120, 140, 160),
              blood=(140, 30, 30), eyes=(255, 60, 40, 255), mouth_open=True, gown=True)


# ====================================================================== models / blockstates
EGGS =["walker_zombie", "runner_zombie", "heavy_zombie", "screamer_zombie", "survivor"]


def make_models():
    m = os.path.join(ASSETS, "models", "item")
    write_json(os.path.join(m, "pistol.json"),
               {"parent": "minecraft:item/generated", "textures": {"layer0": f"{MOD}:item/pistol"}})
    write_json(os.path.join(m, "pistol_ammo.json"),
               {"parent": "minecraft:item/generated", "textures": {"layer0": f"{MOD}:item/pistol_ammo"}})
    for i in range(1, 7):
        write_json(os.path.join(m, f"journal_page_{i}.json"),
                   {"parent": "minecraft:item/generated", "textures": {"layer0": f"{MOD}:item/journal_page"}})
    write_json(os.path.join(m, "barricade.json"), {"parent": f"{MOD}:block/barricade"})
    for e in EGGS:
        suffix = "" if e == "survivor" else "_zombie"
        name = e if e == "survivor" else e
        write_json(os.path.join(m, f"{name}_spawn_egg.json"), {"parent": "minecraft:item/template_spawn_egg"})

    # block model: boarded planks, thin on Z (rotated by blockstate)
    def cube(frm, to):
        faces = {f: {"texture": "#planks"} for f in ("north", "south", "east", "west", "up", "down")}
        return {"from": frm, "to": to, "faces": faces}

    elements = [
        cube([0, 1, 6], [16, 4, 10]),
        cube([0, 6, 6], [16, 9, 10]),
        cube([0, 11, 6], [16, 14, 10]),
        cube([1, 0, 5], [4, 16, 6]),
        cube([12, 0, 5], [15, 16, 6]),
        cube([1, 0, 10], [4, 16, 11]),
        cube([12, 0, 10], [15, 16, 11]),
    ]
    write_json(os.path.join(ASSETS, "models", "block", "barricade.json"), {
        "parent": "minecraft:block/block",
        "textures": {"planks": f"{MOD}:block/barricade", "particle": f"{MOD}:block/barricade"},
        "elements": elements,
    })
    model = f"{MOD}:block/barricade"
    write_json(os.path.join(ASSETS, "blockstates", "barricade.json"), {"variants": {
        "facing=north": {"model": model},
        "facing=east": {"model": model, "y": 90},
        "facing=south": {"model": model, "y": 180},
        "facing=west": {"model": model, "y": 270},
    }})


# ====================================================================== language
def tr(en, th):
    return {"en": en, "th": th}


LANG = {
    "itemGroup.palefall.main": tr("The Pale Fall", "The Pale Fall"),
    "item.palefall.pistol": tr("Pistol", "ปืนพก"),
    "item.palefall.pistol_ammo": tr("Pistol Ammo", "กระสุนปืนพก"),
    "block.palefall.barricade": tr("Barricade", "แผงไม้กั้น"),
    "item.palefall.walker_zombie_spawn_egg": tr("Walker Spawn Egg", "ไข่เกิดซอมบี้เดินช้า"),
    "item.palefall.runner_zombie_spawn_egg": tr("Runner Spawn Egg", "ไข่เกิดซอมบี้วิ่ง"),
    "item.palefall.heavy_zombie_spawn_egg": tr("Heavy Spawn Egg", "ไข่เกิดซอมบี้เกราะหนัก"),
    "item.palefall.screamer_zombie_spawn_egg": tr("Screamer Spawn Egg", "ไข่เกิดซอมบี้กรีดร้อง"),
    "item.palefall.survivor_spawn_egg": tr("Survivor Spawn Egg", "ไข่เกิดผู้รอดชีวิต"),
    "entity.palefall.walker_zombie": tr("Walker", "ซอมบี้เดินช้า"),
    "entity.palefall.runner_zombie": tr("Runner", "ซอมบี้วิ่ง"),
    "entity.palefall.heavy_zombie": tr("Heavy", "ซอมบี้เกราะหนัก"),
    "entity.palefall.screamer_zombie": tr("Screamer", "ซอมบี้กรีดร้อง"),
    "entity.palefall.survivor": tr("Survivor", "ผู้รอดชีวิต"),
    "npc.palefall.kit": tr("Ranger Kit", "เรนเจอร์ คิท"),
    "tooltip.palefall.pistol": tr("Right-click to fire. Uses Pistol Ammo. Aim for the head.",
                                  "คลิกขวาเพื่อยิง ใช้กระสุนปืนพก เล็งที่หัวจะแรงกว่า"),
    "tooltip.palefall.pistol_noise": tr("Gunfire attracts nearby zombies.", "เสียงปืนดึงดูดซอมบี้ในระแวกใกล้เคียง"),
    "tooltip.palefall.journal_page": tr("Journal page %s - right-click to read", "หน้าบันทึกที่ %s - คลิกขวาเพื่ออ่าน"),
    "message.palefall.no_ammo": tr("Out of ammo!", "กระสุนหมด!"),
    "message.palefall.headshot": tr("Headshot!", "เฮดช็อต!"),
    "message.palefall.welcome": tr("You open your eyes in the dark. A crumpled page is stuffed in your pocket...",
                                   "คุณลืมตาขึ้นในความมืด... มีกระดาษยับๆ แผ่นหนึ่งถูกยัดไว้ในกระเป๋า"),
    "message.palefall.welcome_hint": tr("Right-click the journal page to read it. Type /palefall quest to see your objective.",
                                        "คลิกขวาที่หน้าบันทึกเพื่ออ่าน พิมพ์ /palefall quest เพื่อดูภารกิจ"),
    "message.palefall.distant_horde": tr("You hear a horde somewhere in the dark...", "ได้ยินเสียงฝูงซอมบี้ไกลๆ ในความมืด..."),
    "message.palefall.blood_moon": tr("The moon turns red... something is coming tonight.",
                                      "จันทร์กลายเป็นสีเลือด... คืนนี้มีบางอย่างกำลังมา"),
    "message.palefall.quest_update": tr("Objective updated!", "ภารกิจอัปเดต!"),
    "message.palefall.quest_header": tr("Current objective", "ภารกิจปัจจุบัน"),
    "message.palefall.kit_gift": tr("Kit presses a handful of bullets into your palm.", "คิทยัดกระสุนใส่มือคุณหนึ่งกำ"),
    "message.palefall.horde_spawned": tr("Spawned %s zombies.", "เรียกซอมบี้ออกมา %s ตัว"),
    "quest.palefall.stage.0": tr("Read Dr. Mara's note (right-click the journal page).",
                                 "อ่านบันทึกของดร.มารา (คลิกขวาที่หน้าบันทึก)"),
    "quest.palefall.stage.1": tr("Get a pistol: search a police station or craft one.",
                                 "หาปืนพก: ค้นสถานีตำรวจ หรือคราฟต์เอง"),
    "quest.palefall.stage.2": tr("Kill zombies: %1$s / %2$s", "กำจัดซอมบี้: %1$s / %2$s"),
    "quest.palefall.stage.3": tr("Find and read journal pages: %3$s / %4$s",
                                 "ตามหาและอ่านหน้าบันทึก: %3$s / %4$s"),
    "quest.palefall.stage.4": tr("Report to Ranger Kit in the bunker.", "กลับไปรายงานเรนเจอร์ คิท ที่หลุมหลบภัย"),
    "quest.palefall.stage.5": tr("Chapter 1 complete. The lab beneath the meteor awaits... (to be continued)",
                                 "จบตอนที่ 1 ห้องแล็บใต้หลุมดาวตกกำลังรออยู่... (โปรดติดตามตอนต่อไป)"),
    "dialogue.palefall.kit.0": tr("You're up! Read the note you were carrying first, then we talk.",
                                  "ตื่นแล้วเหรอ! อ่านกระดาษที่อยู่ในกระเป๋าก่อน แล้วค่อยคุยกัน"),
    "dialogue.palefall.kit.1": tr("No gun yet? The old police station might have something. Or craft one: iron, a tripwire hook and redstone.",
                                  "ยังไม่มีปืนเหรอ? สถานีตำรวจเก่าอาจมีเหลืออยู่ หรือจะคราฟต์เองก็ได้ ใช้เหล็ก ตะขอสายเบ็ด และเรดสโตน"),
    "dialogue.palefall.kit.2": tr("Learn their types. Runners first, never let a Heavy get close, and kill Screamers before they call the rest.",
                                  "จำชนิดของพวกมันไว้ ตัววิ่งยิงก่อน ตัวเกราะหนักอย่าให้ประชิด ส่วนตัวกรีดร้องต้องรีบเก็บก่อนมันเรียกพวก"),
    "dialogue.palefall.kit.3": tr("Dr. Mara left pages in boarded-up houses and the police station. Axe the barricades, take what you find.",
                                  "ดร.มาราทิ้งหน้าบันทึกไว้ตามบ้านที่ถูกปิดตายกับสถานีตำรวจ ใช้ขวานทุบแผงไม้เข้าไปเอามา"),
    "dialogue.palefall.kit.4": tr("You've read enough. Take this torn map piece and some bullets - the lab is next.",
                                  "อ่านครบแล้วสินะ รับเศษแผนที่นี่ไปพร้อมกระสุนอีกหน่อย ห้องแล็บคือเป้าหมายต่อไป"),
    "dialogue.palefall.kit.5": tr("The lab isn't ready for us yet. Stay alive, keep the barricades up. We'll go soon.",
                                  "ห้องแล็บยังไม่พร้อมให้เราเข้า เอาตัวรอดไว้ก่อน รักษาแผงไม้ให้แน่น เดี๋ยวเราจะไปกัน"),
}

PAGES = {
    1: (tr("Dr. Mara's Note - Page 1", "บันทึกของดร.มารา - หน้า 1"),
        tr("If you are reading this you are still breathing - that is good news. The pale meteor fell three nights ago and its spores turned the town into... them. I am Dr. Mara Veln. Your body resists the spores, so I hid you in the bunker. Find a weapon, then follow my trail. I am working on a cure.",
           "ถ้าคุณอ่านอยู่ แปลว่าคุณยังหายใจ - นั่นคือข่าวดี ดาวตกสีซีดตกลงมาเมื่อสามคืนก่อน สปอร์ของมันเปลี่ยนคนทั้งเมืองให้กลายเป็นพวกนั้น ฉันคือดร.มารา เวลน์ ร่างกายคุณต้านทานสปอร์ได้ ฉันจึงพาคุณมาซ่อนในหลุมหลบภัย ออกไปหาอาวุธ แล้วตามร่องรอยของฉัน ฉันกำลังทำยาแก้อยู่")),
    2: (tr("The First Night - Page 2", "คืนแรก - หน้า 2"),
        tr("They are not like in the stories. They hunt at night and noise is bait. A gun helps, but every shot calls the pack. Runners first. Never let the armoured ones close. And the screamers... kill them before they call the rest. Board your windows. Always.",
           "พวกมันไม่เหมือนในนิทาน มันออกล่าตอนกลางคืนและเสียงดังคือเหยื่อล่อ ปืนช่วยได้ แต่ทุกนัดที่ยิงจะเรียกฝูงเข้ามา ตัววิ่งต้องยิงก่อน ตัวเกราะหนักอย่าให้ประชิด ส่วนตัวกรีดร้อง... รีบเก็บก่อนมันเรียกพวก ปิดหน้าต่างด้วยแผงไม้ไว้เสมอ")),
    3: (tr("The Sealed House - Page 3", "บ้านที่ปิดตาย - หน้า 3"),
        tr("We nailed every board shut on Tuesday night. My daughter says she hears her mother calling outside the door... her mother left us yesterday. Do not open the door, however much the voice sounds like someone you love. - Pim",
           "เราตอกไม้ปิดทุกบานตั้งแต่คืนวันอังคาร ลูกสาวบอกว่าได้ยินแม่เรียกอยู่นอกประตู... แต่แม่ของเธอจากเราไปตั้งแต่เมื่อวาน อย่าเปิดประตู ไม่ว่าเสียงข้างนอกจะเหมือนคนที่เรารักแค่ไหน - พิม")),
    4: (tr("Sheriff's Report - Page 4", "รายงานของนายอำเภอ - หน้า 4"),
        tr("Sheriff Tom Harlan. The villagers who collected meteor fragments were the first to turn. Dr. Mara has taken the fragments from the evidence room. All she left me is this report and my spare pistol. If anyone finds this: the evidence room is boarded up. Bring an axe.",
           "นายอำเภอ ทอม ฮาร์แลน ชาวบ้านที่ไปเก็บเศษดาวตกคือกลุ่มแรกที่เปลี่ยน ดร.มาราเอาเศษหินไปจากห้องหลักฐานแล้ว เหลือไว้แค่รายงานนี้กับปืนสำรองของผม ถ้าใครเจอ: ห้องหลักฐานถูกตอกไม้ปิดไว้ เอาขวานมาด้วย")),
    5: (tr("Patient Zero - Page 5", "ผู้ป่วยศูนย์ - หน้า 5"),
        tr("The first patient was Professor Orrin. He touched the meteor before anyone. He is no ordinary infected - he lies beneath the old lab and his spores command the whole horde. Stop him and the horde falls apart. But the cure needs three parts: the shard, the serum, and the core.",
           "ผู้ป่วยรายแรกคือศาสตราจารย์ออร์ริน เขาสัมผัสดาวตกก่อนใคร ตอนนี้เขาไม่ใช่ซอมบี้ธรรมดา เขานอนอยู่ใต้ห้องแล็บเก่า และสปอร์ของเขาสั่งการฝูงทั้งหมด หยุดเขาได้ ฝูงจะสลาย แต่ยาแก้ต้องมีสามส่วน คือ เศษหิน เซรุ่ม และแกนกลาง")),
    6: (tr("Torn Map - Page 6", "แผนที่ฉีกขาด - หน้า 6"),
        tr("Mara's handwriting: 'The lab is underground, south of the crater, where the pale dust lies thickest. I am waiting. Hurry.'  (To be continued...)",
           "ลายมือดร.มารา: 'ห้องแล็บอยู่ใต้ดิน ทางใต้ของหลุมดาวตก ตรงที่ผงสีซีดหนาที่สุด ฉันรออยู่ รีบมานะ'  (โปรดติดตามตอนต่อไป...)")),
}

for _i, (_t, _b) in PAGES.items():
    LANG[f"item.palefall.journal_page_{_i}"] = tr(f"Journal Page {_i}", f"หน้าบันทึกที่ {_i}")
    LANG[f"journal.palefall.{_i}.title"] = _t
    LANG[f"journal.palefall.{_i}.body"] = _b


def make_lang():
    write_json(os.path.join(ASSETS, "lang", "en_us.json"), {k: v["en"] for k, v in LANG.items()})
    write_json(os.path.join(ASSETS, "lang", "th_th.json"), {k: v["th"] for k, v in LANG.items()})


# ====================================================================== data: loot / recipes / tags / worldgen
def item(name, weight=None, count=None):
    e = {"type": "minecraft:item", "name": name}
    if weight is not None:
        e["weight"] = weight
    if count:
        e["functions"] = [{"function": "minecraft:set_count",
                           "count": {"type": "minecraft:uniform", "min": count[0], "max": count[1]}}]
    return e


def pool(rolls, entries):
    r = rolls if isinstance(rolls, int) else {"type": "minecraft:uniform", "min": rolls[0], "max": rolls[1]}
    return {"rolls": r, "entries": entries}


def loot(pools):
    return {"type": "minecraft:chest", "pools": pools}


def make_data():
    lt = os.path.join(DATA, "loot_table")
    write_json(os.path.join(lt, "chests", "bunker.json"), loot([
        pool(1, [item(f"{MOD}:journal_page_2")]),
        pool((4, 6), [
            item("minecraft:bread", 10, (2, 4)), item("minecraft:cooked_beef", 6, (1, 3)),
            item("minecraft:apple", 5, (1, 3)), item("minecraft:iron_ingot", 6, (1, 3)),
            item(f"{MOD}:pistol_ammo", 8, (4, 8)), item("minecraft:torch", 4, (4, 8)),
            item(f"{MOD}:barricade", 5, (2, 4)), item("minecraft:golden_apple", 1),
        ]),
    ]))
    write_json(os.path.join(lt, "chests", "boarded_house.json"), loot([
        pool(1, [item(f"{MOD}:journal_page_3")]),
        pool((2, 4), [
            item("minecraft:bread", 8, (1, 3)), item("minecraft:cooked_chicken", 5, (1, 2)),
            item("minecraft:oak_planks", 6, (4, 12)), item("minecraft:stick", 6, (2, 6)),
            item(f"{MOD}:barricade", 6, (1, 3)), item("minecraft:iron_nugget", 5, (2, 6)),
            item(f"{MOD}:pistol_ammo", 4, (2, 5)), item(f"{MOD}:pistol", 1),
        ]),
    ]))
    write_json(os.path.join(lt, "chests", "police_station.json"), loot([
        pool(1, [item(f"{MOD}:journal_page_4")]),
        pool((3, 5), [
            item(f"{MOD}:pistol_ammo", 10, (4, 10)), item(f"{MOD}:pistol", 2),
            item("minecraft:iron_ingot", 8, (2, 4)), item("minecraft:gunpowder", 8, (2, 5)),
            item("minecraft:iron_nugget", 8, (4, 9)), item("minecraft:shield", 2),
            item("minecraft:chainmail_chestplate", 2), item("minecraft:iron_helmet", 1),
            item("minecraft:bread", 4, (1, 3)), item("minecraft:cooked_beef", 5, (1, 3)),
        ]),
    ]))
    write_json(os.path.join(lt, "chests", "police_evidence.json"), loot([
        pool(1, [item(f"{MOD}:pistol")]),
        pool(1, [item(f"{MOD}:journal_page_5")]),
        pool((2, 3), [
            item(f"{MOD}:pistol_ammo", 10, (8, 16)), item("minecraft:iron_ingot", 5, (2, 5)),
            item("minecraft:gunpowder", 6, (3, 6)), item("minecraft:golden_apple", 1),
        ]),
    ]))
    write_json(os.path.join(lt, "blocks", "barricade.json"), {
        "type": "minecraft:block",
        "pools": [{"rolls": 1, "bonus_rolls": 0.0,
                   "entries": [{"type": "minecraft:item", "name": f"{MOD}:barricade"}],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}],
    })

    rc = os.path.join(DATA, "recipe")
    write_json(os.path.join(rc, "pistol.json"), {
        "type": "minecraft:crafting_shaped", "category": "equipment",
        "pattern": ["III", "ITR"],
        "key": {"I": {"item": "minecraft:iron_ingot"}, "T": {"item": "minecraft:tripwire_hook"},
                "R": {"item": "minecraft:redstone"}},
        "result": {"id": f"{MOD}:pistol", "count": 1},
    })
    write_json(os.path.join(rc, "pistol_ammo.json"), {
        "type": "minecraft:crafting_shapeless", "category": "equipment",
        "ingredients": [{"item": "minecraft:iron_nugget"}, {"item": "minecraft:gunpowder"}],
        "result": {"id": f"{MOD}:pistol_ammo", "count": 4},
    })
    write_json(os.path.join(rc, "barricade.json"), {
        "type": "minecraft:crafting_shaped", "category": "building",
        "pattern": ["PPP", "SSS"],
        "key": {"P": {"tag": "minecraft:planks"}, "S": {"item": "minecraft:stick"}},
        "result": {"id": f"{MOD}:barricade", "count": 2},
    })

    write_json(os.path.join(ROOT, "data", "minecraft", "tags", "block", "mineable", "axe.json"),
               {"replace": False, "values": [f"{MOD}:barricade"]})

    # ---- worldgen
    write_json(os.path.join(DATA, "tags", "worldgen", "biome", "has_structure.json"), {"values": [
        "minecraft:plains", "minecraft:sunflower_plains", "minecraft:meadow", "minecraft:snowy_plains",
        "minecraft:savanna", "minecraft:desert", "#minecraft:is_forest", "#minecraft:is_taiga",
        "#minecraft:is_hill",
    ]})

    structures = {
        # name: (spacing, separation, salt, step, start_height, adaptation)
        "boarded_house": (14, 5, 1190331, "surface_structures", -2, "beard_thin"),
        "police_station": (30, 10, 1190332, "surface_structures", -2, "beard_thin"),
        "survivor_bunker": (36, 12, 1190333, "underground_structures", -10, "none"),
    }
    for name, (spacing, sep, salt, step, sh, adapt) in structures.items():
        write_json(os.path.join(DATA, "worldgen", "template_pool", f"{name}.json"), {
            "fallback": "minecraft:empty",
            "elements": [{"weight": 1, "element": {
                "element_type": "minecraft:single_pool_element",
                "location": f"{MOD}:{name}",
                "processors": "minecraft:empty",
                "projection": "rigid"}}],
        })
        write_json(os.path.join(DATA, "worldgen", "structure", f"{name}.json"), {
            "type": "minecraft:jigsaw",
            "biomes": f"#{MOD}:has_structure",
            "step": step,
            "spawn_overrides": {},
            "terrain_adaptation": adapt,
            "start_pool": f"{MOD}:{name}",
            "size": 1,
            "start_height": {"absolute": sh},
            "project_start_to_heightmap": "WORLD_SURFACE_WG",
            "max_distance_from_center": 80,
            "use_expansion_hack": False,
        })
        write_json(os.path.join(DATA, "worldgen", "structure_set", f"{name}.json"), {
            "structures": [{"structure": f"{MOD}:{name}", "weight": 1}],
            "placement": {"type": "minecraft:random_spread", "spacing": spacing,
                          "separation": sep, "salt": salt},
        })


# ====================================================================== NBT writer (structure files)
def Byte(v): return (1, v)
def Int(v): return (3, v)
def Str(v): return (8, v)
def Dbl(v): return (6, float(v))
def NList(items): return (9, list(items))
def Comp(d): return (10, dict(d))


def _payload(tag):
    t, v = tag
    if t == 1:
        return struct.pack(">b", v)
    if t == 3:
        return struct.pack(">i", v)
    if t == 6:
        return struct.pack(">d", v)
    if t == 8:
        b = v.encode("utf-8")
        return struct.pack(">H", len(b)) + b
    if t == 9:
        tid = v[0][0] if v else 0
        return struct.pack(">bi", tid, len(v)) + b"".join(_payload(x) for x in v)
    if t == 10:
        out = b""
        for k, x in v.items():
            kb = k.encode("utf-8")
            out += struct.pack(">b", x[0]) + struct.pack(">H", len(kb)) + kb + _payload(x)
        return out + b"\x00"
    raise ValueError(t)


def write_nbt(path, root_compound):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    data = struct.pack(">bH", 10, 0) + _payload(root_compound)
    with gzip.open(path, "wb") as f:
        f.write(data)


class Struct:
    def __init__(self, name, sx, sy, sz):
        self.name, self.size = name, (sx, sy, sz)
        self.blocks = {}      # (x,y,z) -> (block, props_tuple, nbt)
        self.entities = []

    def set(self, x, y, z, block, props=None, nbt=None):
        sx, sy, sz = self.size
        assert 0 <= x < sx and 0 <= y < sy and 0 <= z < sz, (self.name, x, y, z, self.size)
        self.blocks[(x, y, z)] = (block, tuple(sorted((props or {}).items())), nbt)

    def fill(self, x1, y1, z1, x2, y2, z2, block, props=None):
        for x in range(min(x1, x2), max(x1, x2) + 1):
            for y in range(min(y1, y2), max(y1, y2) + 1):
                for z in range(min(z1, z2), max(z1, z2) + 1):
                    self.set(x, y, z, block, props)

    def shell(self, x1, y1, z1, x2, y2, z2, block, props=None):
        """walls/floor/ceiling only"""
        for x in range(x1, x2 + 1):
            for y in range(y1, y2 + 1):
                for z in range(z1, z2 + 1):
                    if x in (x1, x2) or y in (y1, y2) or z in (z1, z2):
                        self.set(x, y, z, block, props)

    def chest(self, x, y, z, facing, loot_table):
        self.set(x, y, z, "minecraft:chest", {"facing": facing, "type": "single"},
                 Comp({"id": Str("minecraft:chest"), "LootTable": Str(loot_table)}))

    def mob(self, entity_id, x, y, z, extra=None):
        tags = {
            "id": Str(entity_id),
            "PersistenceRequired": Byte(1),
            "Pos": NList([Dbl(x), Dbl(y), Dbl(z)]),
        }
        tags.update(extra or {})
        self.entities.append(Comp({
            "pos": NList([Dbl(x), Dbl(y), Dbl(z)]),
            "blockPos": NList([Int(int(x // 1)), Int(int(y // 1)), Int(int(z // 1))]),
            "nbt": Comp(tags),
        }))

    def save(self):
        palette, index = [], {}
        blocks = []
        for (x, y, z), (block, props, nbt) in self.blocks.items():
            key = (block, props)
            if key not in index:
                index[key] = len(palette)
                entry = {"Name": Str(block)}
                if props:
                    entry["Properties"] = Comp({k: Str(str(v).lower() if isinstance(v, bool) else str(v))
                                                for k, v in props})
                palette.append(Comp(entry))
            b = {"pos": NList([Int(x), Int(y), Int(z)]), "state": Int(index[key])}
            if nbt is not None:
                b["nbt"] = nbt
            blocks.append(Comp(b))
        root = Comp({
            "DataVersion": Int(DATA_VERSION),
            "size": NList([Int(s) for s in self.size]),
            "palette": NList(palette),
            "blocks": NList(blocks),
            "entities": NList(self.entities),
        })
        write_nbt(os.path.join(DATA, "structure", f"{self.name}.nbt"), root)
        return len(self.blocks), len(palette)


AIR = "minecraft:air"
KIT_NAME = '{"translate":"npc.palefall.kit"}'


def scatter(s, rng, x1, y1, z1, x2, y2, z2, base, alts, chance):
    """fill with base, randomly swapping in alternates (weathering)."""
    for x in range(x1, x2 + 1):
        for y in range(y1, y2 + 1):
            for z in range(z1, z2 + 1):
                s.set(x, y, z, rng.choice(alts) if rng.random() < chance else base)


# ---------------------------------------------------------------------- boarded house
def build_boarded_house():
    rng = random.Random(101)
    s = Struct("boarded_house", 9, 10, 10)
    s.fill(0, 3, 0, 8, 9, 9, AIR)                                         # clear space
    scatter(s, rng, 0, 0, 0, 8, 1, 8, "minecraft:cobblestone", ["minecraft:mossy_cobblestone"], 0.3)
    s.fill(0, 2, 0, 8, 2, 8, "minecraft:oak_planks")                      # floor
    s.fill(3, 2, 9, 5, 2, 9, "minecraft:oak_planks")                      # porch
    s.fill(3, 1, 9, 5, 1, 9, "minecraft:cobblestone")

    # walls
    for y in (3, 4, 5):
        for x in range(0, 9):
            for z in (0, 8):
                s.set(x, y, z, "minecraft:oak_planks")
        for z in range(0, 9):
            for x in (0, 8):
                s.set(x, y, z, "minecraft:oak_planks")
    for cx, cz in ((0, 0), (8, 0), (0, 8), (8, 8)):
        s.fill(cx, 3, cz, cx, 5, cz, "minecraft:oak_log", {"axis": "y"})
    s.fill(1, 3, 0, 7, 3, 0, "minecraft:stone_bricks")                    # stone plinth
    s.fill(1, 3, 8, 7, 3, 8, "minecraft:stone_bricks")

    # barricaded windows (y=4)
    for x in (2, 6):
        s.set(x, 4, 0, "minecraft:cobweb")
        s.set(x, 4, 0, "palefall:barricade", {"facing": "north"})
        s.set(x, 4, 8, "palefall:barricade", {"facing": "south"})
    for z in (2, 6):
        s.set(0, 4, z, "palefall:barricade", {"facing": "west"})
        s.set(8, 4, z, "palefall:barricade", {"facing": "east"})

    # front door + barricade across it
    s.set(4, 3, 8, "minecraft:oak_door", {"facing": "south", "half": "lower", "hinge": "left", "open": False, "powered": False})
    s.set(4, 4, 8, "minecraft:oak_door", {"facing": "south", "half": "upper", "hinge": "left", "open": False, "powered": False})
    s.set(4, 3, 9, "palefall:barricade", {"facing": "south"})
    s.set(4, 4, 9, "palefall:barricade", {"facing": "south"})

    # gabled roof (ridge along X, slopes along Z)
    for x in range(0, 9):
        for z in range(1, 8):
            s.set(x, 6, z, "minecraft:spruce_planks")
        s.set(x, 6, 0, "minecraft:spruce_stairs", {"facing": "south", "half": "bottom"})
        s.set(x, 6, 8, "minecraft:spruce_stairs", {"facing": "north", "half": "bottom"})
        for z in range(2, 7):
            s.set(x, 7, z, "minecraft:spruce_planks")
        s.set(x, 7, 1, "minecraft:spruce_stairs", {"facing": "south", "half": "bottom"})
        s.set(x, 7, 7, "minecraft:spruce_stairs", {"facing": "north", "half": "bottom"})
        for z in range(3, 6):
            s.set(x, 8, z, "minecraft:spruce_planks")
        s.set(x, 8, 2, "minecraft:spruce_stairs", {"facing": "south", "half": "bottom"})
        s.set(x, 8, 6, "minecraft:spruce_stairs", {"facing": "north", "half": "bottom"})
        s.set(x, 9, 4, "minecraft:spruce_planks")
        s.set(x, 9, 3, "minecraft:spruce_stairs", {"facing": "south", "half": "bottom"})
        s.set(x, 9, 5, "minecraft:spruce_stairs", {"facing": "north", "half": "bottom"})

    # interior
    s.set(1, 3, 1, "minecraft:crafting_table")
    s.chest(7, 3, 1, "south", "palefall:chests/boarded_house")
    s.set(1, 3, 6, "minecraft:furnace", {"facing": "east", "lit": False})
    s.fill(1, 3, 3, 1, 4, 3, "minecraft:bookshelf")
    s.set(4, 3, 4, "minecraft:oak_fence")
    s.set(4, 4, 4, "minecraft:oak_pressure_plate")
    s.set(4, 5, 4, "minecraft:lantern", {"hanging": True})
    for (x, y, z) in ((1, 5, 7), (7, 5, 1), (7, 5, 7), (1, 5, 1)):
        s.set(x, y, z, "minecraft:cobweb")
    s.mob("palefall:walker_zombie", 3.5, 3.0, 4.5)
    s.mob("palefall:walker_zombie", 5.5, 3.0, 2.5)
    return s.save()


# ---------------------------------------------------------------------- police station
def build_police_station():
    rng = random.Random(202)
    W, D = 15, 11          # x 0..14, z 0..10
    s = Struct("police_station", 15, 12, 12)
    s.fill(0, 3, 0, 14, 10, 11, AIR)
    scatter(s, rng, 0, 0, 0, 14, 1, 10, "minecraft:stone_bricks", ["minecraft:mossy_stone_bricks", "minecraft:cracked_stone_bricks"], 0.25)
    s.fill(0, 2, 0, 14, 2, 10, "minecraft:smooth_stone")
    s.fill(6, 2, 11, 8, 2, 11, "minecraft:smooth_stone")
    s.fill(6, 1, 11, 8, 1, 11, "minecraft:stone_bricks")

    # outer walls y3..6
    for y in range(3, 7):
        for x in range(0, 15):
            for z in (0, 10):
                alt = ["minecraft:cracked_stone_bricks", "minecraft:mossy_stone_bricks"]
                s.set(x, y, z, rng.choice(alt) if rng.random() < 0.2 else "minecraft:stone_bricks")
        for z in range(0, 11):
            for x in (0, 14):
                s.set(x, y, z, "minecraft:stone_bricks")
    s.fill(0, 7, 0, 14, 7, 10, "minecraft:stone_bricks")                  # flat roof
    s.fill(0, 8, 0, 14, 8, 0, "minecraft:stone_brick_slab", {"type": "bottom"})
    s.fill(0, 8, 10, 14, 8, 10, "minecraft:stone_brick_slab", {"type": "bottom"})
    s.fill(0, 8, 0, 0, 8, 10, "minecraft:stone_brick_slab", {"type": "bottom"})
    s.fill(14, 8, 0, 14, 8, 10, "minecraft:stone_brick_slab", {"type": "bottom"})

    # front door + barricade
    s.set(7, 3, 10, "minecraft:spruce_door", {"facing": "south", "half": "lower", "hinge": "left", "open": False, "powered": False})
    s.set(7, 4, 10, "minecraft:spruce_door", {"facing": "south", "half": "upper", "hinge": "left", "open": False, "powered": False})
    s.set(7, 3, 11, "palefall:barricade", {"facing": "south"})
    s.set(7, 4, 11, "palefall:barricade", {"facing": "south"})

    # barricaded windows (2 tall: y4..5)
    for x in (2, 4, 10, 12):
        for y in (4, 5):
            s.set(x, y, 10, "palefall:barricade", {"facing": "south"})
    for z in (3, 7):
        for y in (4, 5):
            s.set(0, y, z, "palefall:barricade", {"facing": "west"})
            s.set(14, y, z, "palefall:barricade", {"facing": "east"})

    # partition: lobby (x1..8) | cell block (x10..13), wall at x=9 with two gaps (z=3, z=7)
    for y in range(3, 7):
        for z in range(1, 10):
            if z in (3, 7) and y in (3, 4):
                continue
            s.set(9, y, z, "minecraft:stone_bricks")
    s.fill(10, 3, 5, 13, 6, 5, "minecraft:iron_bars")                     # between the cells
    for (x, y, z) in ((10, 3, 3), (10, 3, 7)):
        pass
    s.set(13, 3, 1, "minecraft:hay_block", {"axis": "x"})                # cell bedding
    s.set(13, 3, 9, "minecraft:hay_block", {"axis": "x"})

    # evidence room (NW): interior x1..3 z1..3, walls x=4 / z=4, doorway at (2,*,4)
    for y in range(3, 7):
        for z in range(1, 5):
            s.set(4, y, z, "minecraft:stone_bricks")
        for x in range(1, 5):
            if x == 2 and y in (3, 4):
                continue
            s.set(x, y, 4, "minecraft:stone_bricks")
    s.set(2, 3, 4, "palefall:barricade", {"facing": "south"})
    s.set(2, 4, 4, "palefall:barricade", {"facing": "south"})
    s.chest(1, 3, 1, "south", "palefall:chests/police_evidence")
    s.fill(2, 3, 1, 3, 3, 1, "minecraft:bookshelf")

    # lobby furniture
    s.fill(2, 3, 7, 5, 3, 7, "minecraft:spruce_planks")                   # front desk
    s.chest(6, 3, 7, "north", "palefall:chests/police_station")
    s.set(1, 3, 9, "minecraft:crafting_table")
    s.set(8, 3, 1, "minecraft:barrel", {"facing": "up", "open": False})
    for (x, z) in ((4, 5), (11, 3), (11, 7)):
        s.set(x, 6, z, "minecraft:lantern", {"hanging": True})
    for (x, y, z) in ((1, 6, 9), (8, 6, 9), (8, 6, 1), (13, 6, 1), (13, 6, 9)):
        s.set(x, y, z, "minecraft:cobweb")

    # the staff and the "prisoners"
    s.mob("palefall:heavy_zombie", 6.5, 3.0, 3.5)
    s.mob("palefall:runner_zombie", 3.5, 3.0, 9.5)
    s.mob("palefall:walker_zombie", 11.5, 3.0, 2.5)
    s.mob("palefall:walker_zombie", 11.5, 3.0, 8.5)
    return s.save()


# ---------------------------------------------------------------------- survivor bunker
def build_bunker():
    rng = random.Random(303)
    s = Struct("survivor_bunker", 13, 11, 13)
    # shell x0..12, y0..5, z0..12 ; interior x1..11, y1..4, z1..11
    scatter(s, rng, 0, 0, 0, 12, 5, 12, "minecraft:stone_bricks", ["minecraft:cracked_stone_bricks", "minecraft:mossy_stone_bricks"], 0.12)
    s.fill(1, 1, 1, 11, 4, 11, AIR)
    s.fill(1, 0, 1, 11, 0, 11, "minecraft:polished_andesite")

    # entrance shaft at (6, y, 1), ladder on the z=0 wall
    for y in range(5, 10):
        s.set(5, y, 1, "minecraft:stone_bricks")
        s.set(7, y, 1, "minecraft:stone_bricks")
        s.set(6, y, 2, "minecraft:stone_bricks")
        s.set(6, y, 0, "minecraft:stone_bricks")
        s.set(6, y, 1, AIR)
    for (x, z) in ((5, 1), (7, 1), (6, 2), (6, 0)):                       # surface ring
        s.set(x, 9, z, "minecraft:cobblestone")
    for y in range(1, 10):
        s.set(6, y, 1, "minecraft:ladder", {"facing": "south"})
    s.set(6, 10, 1, "minecraft:dark_oak_trapdoor", {"facing": "south", "half": "bottom", "open": False, "powered": False})

    # sleeping corner (west)
    s.set(1, 1, 4, "minecraft:red_bed", {"facing": "south", "part": "foot", "occupied": False})
    s.set(1, 1, 5, "minecraft:red_bed", {"facing": "south", "part": "head", "occupied": False})
    s.set(1, 1, 7, "minecraft:red_bed", {"facing": "south", "part": "foot", "occupied": False})
    s.set(1, 1, 8, "minecraft:red_bed", {"facing": "south", "part": "head", "occupied": False})

    # storage + workshop (east)
    s.chest(11, 1, 2, "west", "palefall:chests/bunker")
    s.chest(11, 1, 3, "west", "palefall:chests/bunker")
    s.set(11, 1, 6, "minecraft:crafting_table")
    s.set(11, 1, 7, "minecraft:furnace", {"facing": "west", "lit": False})
    s.fill(11, 1, 9, 11, 2, 9, "minecraft:bookshelf")
    s.fill(11, 1, 10, 11, 2, 10, "minecraft:bookshelf")
    s.set(1, 1, 10, "minecraft:cartography_table")
    s.set(2, 1, 10, "minecraft:barrel", {"facing": "up", "open": False})

    # central table
    s.set(6, 1, 6, "minecraft:oak_fence")
    s.set(6, 2, 6, "minecraft:oak_pressure_plate")

    # lanterns hang from the ceiling (y4)
    for (x, z) in ((3, 6), (9, 6), (6, 10), (6, 3)):
        s.set(x, 4, z, "minecraft:lantern", {"hanging": True})

    s.mob("palefall:survivor", 8.5, 1.0, 7.5, {
        "CustomName": Str(KIT_NAME),
        "CustomNameVisible": Byte(1),
        "Invulnerable": Byte(1),
    })
    return s.save()


def make_structures():
    for fn in (build_boarded_house, build_police_station, build_bunker):
        n_blocks, n_palette = fn()
        print(f"  {fn.__name__}: {n_blocks} blocks, {n_palette} palette entries")


if __name__ == "__main__":
    print("textures..."); make_textures()
    print("skins...");    make_skins()
    print("models...");   make_models()
    print("lang...");     make_lang()
    print("data...");     make_data()
    print("structures..."); make_structures()
    print("done ->", ROOT)
