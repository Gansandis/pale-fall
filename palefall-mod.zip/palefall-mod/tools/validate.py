#!/usr/bin/env python3
"""Sanity checks for generated resources (no Minecraft needed)."""
import glob
import gzip
import json
import os
import re
import struct
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
RES = os.path.join(ROOT, "src", "main", "resources")
errors = []


def err(msg):
    errors.append(msg)
    print("ERROR:", msg)


# ---- NBT reader ---------------------------------------------------------
def read_payload(f, t):
    if t == 1: return struct.unpack(">b", f.read(1))[0]
    if t == 3: return struct.unpack(">i", f.read(4))[0]
    if t == 6: return struct.unpack(">d", f.read(8))[0]
    if t == 8:
        n = struct.unpack(">H", f.read(2))[0]
        return f.read(n).decode("utf-8")
    if t == 9:
        tid, n = struct.unpack(">bi", f.read(5))
        return [read_payload(f, tid) for _ in range(n)]
    if t == 10:
        d = {}
        while True:
            tid = struct.unpack(">b", f.read(1))[0]
            if tid == 0:
                return d
            n = struct.unpack(">H", f.read(2))[0]
            name = f.read(n).decode("utf-8")
            d[name] = read_payload(f, tid)
    raise ValueError(f"unknown tag {t}")


def load_nbt(path):
    with gzip.open(path, "rb") as f:
        t = struct.unpack(">b", f.read(1))[0]
        n = struct.unpack(">H", f.read(2))[0]
        f.read(n)
        return read_payload(f, t)


print("== structures")
KNOWN_BLOCK_PROPS = {  # enough to catch typos in the properties we use
    "facing": {"north", "south", "east", "west", "up", "down"},
    "half": {"upper", "lower", "top", "bottom"},
    "hinge": {"left", "right"},
    "open": {"true", "false"}, "powered": {"true", "false"}, "lit": {"true", "false"},
    "occupied": {"true", "false"}, "hanging": {"true", "false"},
    "part": {"head", "foot"}, "axis": {"x", "y", "z"}, "type": {"single", "bottom", "top", "double"},
}
for path in sorted(glob.glob(os.path.join(RES, "data", "palefall", "structure", "*.nbt"))):
    name = os.path.basename(path)
    nbt = load_nbt(path)
    sx, sy, sz = nbt["size"]
    palette = nbt["palette"]
    for p in palette:
        for k, v in p.get("Properties", {}).items():
            if k in KNOWN_BLOCK_PROPS and v not in KNOWN_BLOCK_PROPS[k]:
                err(f"{name}: bad property {k}={v} on {p['Name']}")
    seen = set()
    for b in nbt["blocks"]:
        x, y, z = b["pos"]
        if not (0 <= x < sx and 0 <= y < sy and 0 <= z < sz):
            err(f"{name}: block out of bounds {b['pos']}")
        if (x, y, z) in seen:
            err(f"{name}: duplicate block at {(x, y, z)}")
        seen.add((x, y, z))
        if not (0 <= b["state"] < len(palette)):
            err(f"{name}: bad palette index")
    ents = [e["nbt"]["id"] for e in nbt["entities"]]
    loot = [b["nbt"]["LootTable"] for b in nbt["blocks"] if "nbt" in b and "LootTable" in b["nbt"]]
    print(f"  {name}: size={nbt['size']} blocks={len(nbt['blocks'])} palette={len(palette)} DataVersion={nbt['DataVersion']}")
    print(f"     entities={ents}")
    print(f"     loot={sorted(set(loot))}")
    for lt in set(loot):
        ns, p = lt.split(":")
        if not os.path.exists(os.path.join(RES, "data", ns, "loot_table", p + ".json")):
            err(f"{name}: loot table {lt} missing")
    for e in nbt["entities"]:
        for c in e["nbt"]["Pos"]:
            pass
        ex, ey, ez = e["pos"]
        if not (0 <= ex < sx and 0 <= ey < sy and 0 <= ez < sz):
            err(f"{name}: entity outside bounds {e['pos']}")

# --- bunker shaft continuity: ladder column must have air path and backing
bn = load_nbt(os.path.join(RES, "data", "palefall", "structure", "survivor_bunker.nbt"))
pal = bn["palette"]
grid = {tuple(b["pos"]): pal[b["state"]]["Name"] for b in bn["blocks"]}
for y in range(1, 10):
    if grid.get((6, y, 1)) != "minecraft:ladder":
        err(f"bunker: no ladder at y={y}")
    if grid.get((6, y, 0)) not in ("minecraft:stone_bricks", "minecraft:cracked_stone_bricks",
                                   "minecraft:mossy_stone_bricks", "minecraft:cobblestone"):
        err(f"bunker: ladder at y={y} has no backing block ({grid.get((6, y, 0))})")
print("  bunker ladder shaft: OK" if not errors else "  bunker ladder shaft: see errors")

# ---- JSON validity ---------------------------------------------------------
print("== json")
count = 0
for path in glob.glob(os.path.join(RES, "**", "*.json"), recursive=True):
    count += 1
    try:
        with open(path, encoding="utf-8") as f:
            json.load(f)
    except Exception as e:  # noqa
        err(f"invalid JSON {path}: {e}")
print(f"  {count} json files parsed")

# ---- registry names <-> models / lang / textures ----------------------------
print("== references")
java_src = ""
for p in glob.glob(os.path.join(ROOT, "src", "**", "*.java"), recursive=True):
    with open(p, encoding="utf-8") as f:
        java_src += f.read() + "\n"

lang = json.load(open(os.path.join(RES, "assets", "palefall", "lang", "en_us.json"), encoding="utf-8"))
th = json.load(open(os.path.join(RES, "assets", "palefall", "lang", "th_th.json"), encoding="utf-8"))
if set(lang) != set(th):
    err(f"lang key mismatch: {set(lang) ^ set(th)}")

# every literal translation key used in Java
keys = set(re.findall(r'"((?:message|quest|dialogue|npc|tooltip|itemGroup)\.palefall[A-Za-z0-9_.]*)"', java_src))
for k in sorted(keys):
    # keys built with a suffix (quest.palefall.stage.<n>) are checked separately
    if k.endswith("."):
        continue
    if k not in lang:
        err(f"lang key used in Java but missing: {k}")
for n in range(6):
    for pre in ("quest.palefall.stage.", "dialogue.palefall.kit."):
        if pre + str(n) not in lang:
            err(f"missing {pre}{n}")
for n in range(1, 7):
    for suf in ("title", "body"):
        if f"journal.palefall.{n}.{suf}" not in lang:
            err(f"missing journal {n} {suf}")

items = set(re.findall(r'register\("([a-z0-9_]+)"', java_src))
items.discard("journal_page_")  # built in a loop (journal_page_1..6) and checked explicitly below
for n in range(1, 7):
    if f"item.palefall.journal_page_{n}" not in lang:
        err(f"lang name missing for journal_page_{n}")
for it in sorted(items):
    if it in ("walker_zombie", "runner_zombie", "heavy_zombie", "screamer_zombie", "survivor", "barricade"):
        continue
    mp = os.path.join(RES, "assets", "palefall", "models", "item", it + ".json")
    if not os.path.exists(mp):
        err(f"item model missing for {it}")
    if f"item.palefall.{it}" not in lang:
        err(f"lang name missing for item {it}")
for e in ("walker_zombie", "runner_zombie", "heavy_zombie", "screamer_zombie", "survivor"):
    if f"entity.palefall.{e}" not in lang:
        err(f"entity name missing {e}")
for n in range(1, 7):
    if not os.path.exists(os.path.join(RES, "assets", "palefall", "models", "item", f"journal_page_{n}.json")):
        err(f"journal_page_{n} model missing")
print("  java keys checked:", len(keys), " registered names:", sorted(items))

# structure worldgen wiring
for n in ("boarded_house", "police_station", "survivor_bunker"):
    for sub in ("structure", "structure_set", "template_pool"):
        if not os.path.exists(os.path.join(RES, "data", "palefall", "worldgen", sub, n + ".json")):
            err(f"worldgen/{sub}/{n}.json missing")
    if not os.path.exists(os.path.join(RES, "data", "palefall", "structure", n + ".nbt")):
        err(f"structure/{n}.nbt missing")

print()
print("FAILED" if errors else "ALL CHECKS PASSED", f"({len(errors)} errors)")
sys.exit(1 if errors else 0)
